// Adicione funcionalidades JavaScript conforme necessário
document.addEventListener('DOMContentLoaded', function() {
    // Exemplo de código JS: Realizar scroll suave ao clicar nos links do menu
    const links = document.querySelectorAll('nav ul li a');

    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});
